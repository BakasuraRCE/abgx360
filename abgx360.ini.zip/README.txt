This abgx360.ini file will get the abgx360 app working again as the IP and domain has changed to:

https://abgx360.xecuter.com but sadly the v1.0.6 app is outdated and does not like https:// as such
the ini file points to proxy site called http://abgx360.cc which will redirect to the right domain.

You will need to place this abgx360.ini file in the folder directly above your StealthFiles folder.

To find out where your StealthFiles folder is, open abgx360 GUI v1.0.2 or later and press Ctrl+F (and click yes to have it opened for you).

Then go one folder up to where you see the abgx360.dat file and put this abgx360.ini file in there right next to it.

Our thanks to TEAM-XECUTER for hosting our GUI and DATABASE and keeping this app still running and working! :)